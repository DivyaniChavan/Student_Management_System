create database Student_Management_System;
use Student_Management_System;
create table Studdata
(
studid int,
studname varchar(20),
studmail varchar(50),
studcity varchar(50),
studstream varchar(50)
);
select * from Studdata;
insert into Studdata (studid,studname,studmail,studcity,studstream)values(1,"Divyani Chavan","chavandivyani6@gmail.com","Pune","Computer");
insert into Studdata (studid,studname,studmail,studcity,studstream)values(2,"Tejashri Bhagwat","teju@gmail.com","Pune","Computer");
INSERT INTO Studdata (studid, studname, studmail, studcity, studstream)
VALUES
    (3, 'John Doe', 'john.doe@email.com', 'New York', 'AIDS'),
    (4, 'Jane Smith', 'jane.smith@email.com', 'Los Angeles', 'Mechnical'),
    (5, 'Alex Johnson', 'alex.johnson@email.com', 'Chicago', 'AIDS'),
    (6, 'Emily Davis', 'emily.davis@email.com', 'Houston', 'AIDS'),
    (7, 'Michael Brown', 'michael.brown@email.com', 'San Francisco', 'Civil'),
    (8, 'Mr Root', 'mrroot@email.com', 'Delhi', 'Computer'),
    (9, 'Michael Brown', 'michael.brown@email.com', 'San Francisco', 'Civil'),
    (10, 'Angel Brown', 'brown@email.com', 'Delhi', 'Mechnical');
select * from Studdata;
ALTER TABLE Studdata ADD PRIMARY KEY (studid);
create table studcourse
(
studid int,
studname varchar(20),
studstream varchar(50)
);
select * from studcourse;
insert into studcourse (studid,studname,studstream)
values(1,"Divyani Chavan","Computer");
ALTER TABLE studcourse ADD PRIMARY KEY (studid);
INSERT INTO studcourse (studid, studname,studstream)
VALUES
	(2,"Tejashri Bhagwat","Computer"),
    (3, 'John Doe','AIDS'),
    (4, 'Jane Smith','Mechnical'),
    (5, 'Alex Johnson','AIDS'),
    (6, 'Emily Davis','AIDS'),
    (7, 'Michael Brown','Civil'),
    (8, 'Mr Root','Computer'),
    (9, 'Michael Brown','Civil'),
    (10, 'Angel Brown','Mechnical');

